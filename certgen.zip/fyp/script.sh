#!/bin/bash

# Set the domains and IP addresses for the certificates
SERVER_DOMAIN=my-server-domain.com
CLIENT_DOMAIN=my-client-domain.com
IP_ADDRESS=127.0.0.1

# Generate a CA private key and certificate
openssl genrsa -out ca.key 4096
openssl req -x509 -new -nodes -key ca.key -sha256 -days 365 -out ca.crt \
    -subj "/C=US/ST=CA/L=SanFrancisco/O=MyOrg/OU=MyDept/CN=MyCA"

# Generate a server private key and certificate signing request (CSR)
openssl genrsa -out server.key 2048
openssl req -new -key server.key -out server.csr \
    -subj "/C=US/ST=CA/L=SanFrancisco/O=MyOrg/OU=MyDept/CN=$SERVER_DOMAIN" \
    -addext "subjectAltName = DNS:$SERVER_DOMAIN,IP:$IP_ADDRESS"

# Generate a server certificate using the CSR and CA
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
    -out server.crt -days 365 -sha256 \
    -extfile <(echo subjectAltName=DNS:$SERVER_DOMAIN,IP:$IP_ADDRESS)

# Generate a client private key and certificate signing request (CSR)
openssl genrsa -out client.key 2048
openssl req -new -key client.key -out client.csr \
    -subj "/C=US/ST=CA/L=SanFrancisco/O=MyOrg/OU=MyDept/CN=$CLIENT_DOMAIN" \
    -addext "subjectAltName = DNS:$CLIENT_DOMAIN"

# Generate a client certificate using the CSR and CA
openssl x509 -req -in client.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
    -out client.crt -days 365 -sha256 \
    -extfile <(echo subjectAltName=DNS:$CLIENT_DOMAIN)
